"use client";

import { useState } from "react";

const LANGUAGES = ["EN", "ES", "FR", "DE", "PT", "HI", "AR", "ID", "JA", "KO"];

export default function Header() {
  const [lang, setLang] = useState("EN");
  const [open, setOpen] = useState(false);

  return (
    <header className="mx-auto mt-4 w-full max-w-[1140px] px-4 sm:mt-8 sm:px-6">
      <div className="glass flex items-center justify-between rounded-[1.5rem] px-5 py-3.5 shadow-glass sm:px-7 sm:py-4">
        <a href="/" className="flex items-baseline gap-1.5 leading-none">
          <span className="text-lg font-bold tracking-tight text-ink sm:text-xl">
            IG REELS
          </span>
          <span className="text-lg font-bold tracking-tight text-brand sm:text-xl">
            DOWNLOADER
          </span>
        </a>

        <div className="relative">
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            aria-haspopup="listbox"
            aria-expanded={open}
            className="rounded-full border border-white/50 bg-white/35 px-4 py-1.5 text-sm font-semibold text-ink shadow-sm transition hover:bg-white/55"
          >
            {lang}
          </button>
          {open && (
            <ul
              role="listbox"
              className="glass-solid absolute right-0 top-full z-10 mt-2 max-h-56 w-28 overflow-auto rounded-2xl p-1.5 shadow-glass"
            >
              {LANGUAGES.map((code) => (
                <li key={code}>
                  <button
                    type="button"
                    role="option"
                    aria-selected={lang === code}
                    onClick={() => {
                      setLang(code);
                      setOpen(false);
                    }}
                    className="w-full rounded-xl px-3 py-1.5 text-left text-sm font-medium text-ink transition hover:bg-brand/10"
                  >
                    {code}
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </header>
  );
}
