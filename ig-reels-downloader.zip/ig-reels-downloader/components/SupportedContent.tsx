const ITEMS = [
  { title: "Video", description: "Feed videos, any length" },
  { title: "Photo", description: "Single images, full resolution" },
  { title: "Reels", description: "Public Reels" },
  { title: "Story", description: "Public stories, when available" },
  { title: "IGTV", description: "Longer-form video posts" },
  { title: "Carousel", description: "Multi-photo and video posts" },
  { title: "Profile photo", description: "View in full size" },
  { title: "More formats", description: "More formats as Instagram changes" },
];

export default function SupportedContent() {
  return (
    <section className="mx-auto w-full max-w-[1140px] px-4 pb-24 pt-20 sm:px-6">
      <hr className="border-t border-ink/10" />
      <h2 className="mt-12 text-center text-2xl font-bold tracking-tight text-ink sm:text-[28px]">
        Supported content
      </h2>

      <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2">
        {ITEMS.map((item) => (
          <div
            key={item.title}
            className="glass-solid group rounded-[1.5rem] p-6 shadow-card transition duration-200 hover:-translate-y-0.5 hover:shadow-glass sm:p-7"
          >
            <h3 className="text-lg font-bold text-ink">{item.title}</h3>
            <p className="mt-1.5 text-[15px] text-slate">{item.description}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
