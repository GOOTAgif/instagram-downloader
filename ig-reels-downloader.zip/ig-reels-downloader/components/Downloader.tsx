"use client";

import { useState, useRef } from "react";
import { validateInstagramUrl } from "@/lib/validateUrl";

type Status = "idle" | "loading" | "success" | "error";

interface MediaFormat {
  id: string;
  kind: "video" | "audio";
  label: string;
  ext: string;
  downloadUrl: string;
}

interface DownloadResult {
  type: "video" | "photo" | "carousel";
  thumbnail: string;
  filenameBase: string;
  formats: MediaFormat[];
}

export default function Downloader() {
  const [url, setUrl] = useState("");
  const [status, setStatus] = useState<Status>("idle");
  const [errorMessage, setErrorMessage] = useState("");
  const [result, setResult] = useState<DownloadResult | null>(null);
  const [selectedFormatId, setSelectedFormatId] = useState<string>("");
  const [copied, setCopied] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const selectedFormat = result?.formats.find(
    (f) => f.id === selectedFormatId
  );

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    const validation = validateInstagramUrl(url);
    if (!validation.valid) {
      setStatus("error");
      setErrorMessage(validation.reason);
      return;
    }

    setStatus("loading");
    setErrorMessage("");
    setResult(null);

    try {
      const res = await fetch("/api/download", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: validation.normalizedUrl }),
      });
      const data = await res.json();

      if (!res.ok || !data.success) {
        setStatus("error");
        setErrorMessage(data.message || "Something went wrong. Try again.");
        return;
      }

      const formats: MediaFormat[] = data.formats ?? [];
      setResult({
        type: data.type,
        thumbnail: data.thumbnail,
        filenameBase: data.filenameBase,
        formats,
      });
      // Default to the highest listed video quality, falling back to
      // whatever format came back first (e.g. a photo's single original).
      setSelectedFormatId(
        formats.find((f) => f.kind === "video")?.id ?? formats[0]?.id ?? ""
      );
      setStatus("success");
    } catch {
      setStatus("error");
      setErrorMessage("Network error. Check your connection and try again.");
    }
  }

  function handleClear() {
    setUrl("");
    setStatus("idle");
    setErrorMessage("");
    setResult(null);
    inputRef.current?.focus();
  }

  async function handleCopy() {
    if (!url) return;
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      // Clipboard API unavailable — fail silently, it's a convenience action.
    }
  }

  return (
    <section className="mx-auto w-full max-w-[720px] px-4 pt-20 text-center sm:px-6 sm:pt-28">
      <form
        onSubmit={handleSubmit}
        className="glass mt-8 rounded-[1.75rem] p-2.5 shadow-glass sm:p-3"
      >
        <div className="flex flex-col gap-2.5 sm:flex-row sm:items-center">
          <label htmlFor="ig-url" className="sr-only">
            Instagram post or Reel URL
          </label>
          <input
            ref={inputRef}
            id="ig-url"
            type="url"
            inputMode="url"
            autoComplete="off"
            spellCheck={false}
            placeholder="https://www.instagram.com/..."
            value={url}
            onChange={(e) => {
              setUrl(e.target.value);
              if (status === "error") setStatus("idle");
            }}
            aria-invalid={status === "error"}
            aria-describedby={status === "error" ? "url-error" : undefined}
            className="min-w-0 flex-1 rounded-2xl border border-white/50 bg-white/40 px-4 py-3.5 text-[15px] text-ink placeholder:text-slate/70 focus:bg-white/70 sm:py-3"
          />
          <button
            type="submit"
            disabled={status === "loading"}
            className="flex w-full shrink-0 items-center justify-center gap-2 rounded-2xl bg-brand px-6 py-3.5 text-[15px] font-semibold text-white shadow-sm transition hover:bg-brand-dark active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-70 sm:w-auto sm:py-3"
          >
            {status === "loading" ? (
              <>
                <Spinner />
                <span>Fetching…</span>
              </>
            ) : (
              "Download"
            )}
          </button>
        </div>

        {url && status !== "loading" && (
          <div className="mt-2 flex justify-center gap-4 px-1 sm:justify-end">
            <button
              type="button"
              onClick={handleCopy}
              className="text-sm font-medium text-slate transition hover:text-ink"
            >
              {copied ? "Copied" : "Copy URL"}
            </button>
            <button
              type="button"
              onClick={handleClear}
              className="text-sm font-medium text-slate transition hover:text-ink"
            >
              Clear
            </button>
          </div>
        )}
      </form>

      {status === "error" && (
        <p
          id="url-error"
          role="alert"
          className="mt-3 text-sm font-medium text-rose-600"
        >
          {errorMessage}
        </p>
      )}

      {status === "success" && result && (
        <div className="glass-solid mt-6 rounded-[1.5rem] p-4 text-left shadow-card sm:p-5">
          <div className="flex items-center gap-4">
            <img
              src={result.thumbnail}
              alt=""
              className="h-16 w-16 shrink-0 rounded-xl object-cover sm:h-20 sm:w-20"
            />
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-semibold text-ink">
                {result.filenameBase}
              </p>
              <p className="text-xs text-slate">Ready to download</p>
            </div>
          </div>

          {result.formats.length > 1 && (
            <div className="mt-4">
              <label
                htmlFor="quality"
                className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate"
              >
                Quality
              </label>
              <div className="flex flex-wrap gap-2" role="radiogroup" aria-label="Download quality">
                {result.formats.map((f) => (
                  <button
                    key={f.id}
                    type="button"
                    role="radio"
                    aria-checked={selectedFormatId === f.id}
                    onClick={() => setSelectedFormatId(f.id)}
                    className={`rounded-xl border px-3.5 py-2 text-sm font-medium transition ${
                      selectedFormatId === f.id
                        ? "border-brand bg-brand/10 text-brand-dark"
                        : "border-ink/10 bg-white/70 text-slate hover:border-ink/20 hover:text-ink"
                    }`}
                  >
                    {f.kind === "audio" ? "🎵 " : ""}
                    {f.label}
                  </button>
                ))}
              </div>
            </div>
          )}

          <a
            href={selectedFormat?.downloadUrl ?? "#"}
            download={
              selectedFormat
                ? `${result.filenameBase}.${selectedFormat.ext}`
                : undefined
            }
            aria-disabled={!selectedFormat}
            className="mt-4 flex w-full items-center justify-center rounded-xl bg-brand px-4 py-3 text-sm font-semibold text-white transition hover:bg-brand-dark sm:w-auto"
          >
            Save {selectedFormat ? `(${selectedFormat.label})` : ""}
          </a>
        </div>
      )}
    </section>
  );
}

function Spinner() {
  return (
    <svg
      className="h-4 w-4 animate-spin text-white"
      viewBox="0 0 24 24"
      fill="none"
      aria-hidden="true"
    >
      <circle
        className="opacity-25"
        cx="12"
        cy="12"
        r="10"
        stroke="currentColor"
        strokeWidth="4"
      />
      <path
        className="opacity-90"
        fill="currentColor"
        d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"
      />
    </svg>
  );
}
