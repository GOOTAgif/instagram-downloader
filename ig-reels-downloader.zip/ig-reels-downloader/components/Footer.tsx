export default function Footer() {
  return (
    <footer className="mx-auto w-full max-w-[1140px] px-4 pb-10 sm:px-6">
      <div className="flex flex-col items-center gap-3 border-t border-ink/10 pt-6 text-sm text-slate sm:flex-row sm:justify-between">
        <p>© 2026 IG Reels Downloader</p>
        <nav className="flex gap-5">
          <a href="/privacy" className="transition hover:text-ink">
            Privacy Policy
          </a>
          <a href="/terms" className="transition hover:text-ink">
            Terms of Service
          </a>
          <a href="/contact" className="transition hover:text-ink">
            Contact
          </a>
        </nav>
      </div>
    </footer>
  );
}
