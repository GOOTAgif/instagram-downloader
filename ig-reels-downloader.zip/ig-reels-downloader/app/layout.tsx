import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://example.com";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: "Instagram Reels Downloader - Download Instagram Videos & Photos",
  description:
    "Download public Instagram Reels, videos and photos with a fast and simple downloader.",
  icons: {
    icon: "/favicon.svg",
  },
  openGraph: {
    title: "IG Reels Downloader",
    description:
      "Download public Instagram Reels, videos and photos with a fast and simple downloader.",
    url: siteUrl,
    siteName: "IG Reels Downloader",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "IG Reels Downloader",
    description:
      "Download public Instagram Reels, videos and photos with a fast and simple downloader.",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={inter.variable}>
      <body className="font-sans antialiased">
        <div className="bg-glow" aria-hidden="true">
          <span />
        </div>
        {children}
      </body>
    </html>
  );
}
