import Header from "@/components/Header";
import Downloader from "@/components/Downloader";
import SupportedContent from "@/components/SupportedContent";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col">
      <Header />
      <Downloader />
      <SupportedContent />
      <Footer />
    </main>
  );
}
