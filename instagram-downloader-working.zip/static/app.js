const form = document.getElementById("downloadForm");
const input = document.getElementById("urlInput");
const button = document.getElementById("downloadBtn");
const message = document.getElementById("message");

function setMessage(text, error=false) {
  message.textContent = text;
  message.className = "message" + (error ? " error" : "");
}

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const url = input.value.trim();

  if (!/^https?:\/\/(www\.)?instagram\.com\//i.test(url)) {
    setMessage("Please paste a valid Instagram URL.", true);
    return;
  }

  button.disabled = true;
  button.classList.add("loading");
  setMessage("Preparing your download…");

  try {
    const res = await fetch("/api/download", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({url})
    });

    const type = res.headers.get("content-type") || "";
    if (!res.ok || type.includes("application/json")) {
      let detail = "Download failed.";
      try { detail = (await res.json()).error || detail; } catch {}
      throw new Error(detail);
    }

    const blob = await res.blob();
    const disposition = res.headers.get("Content-Disposition") || "";
    const match = disposition.match(/filename="?([^"]+)"?/i);
    const filename = match ? match[1] : "instagram-download.mp4";
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
    setMessage("Download started.");
  } catch (err) {
    setMessage(err.message || "Something went wrong.", true);
  } finally {
    button.disabled = false;
    button.classList.remove("loading");
  }
});
